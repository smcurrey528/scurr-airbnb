\c airbnb
\i airbnb.sql